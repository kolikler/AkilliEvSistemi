# Test ustd library on Linux or Mac

## Build

Dependency: CMAKE

```bash
mkdir build
cd build
cmake ..
make
```

then start test with:

```bash
./ustd-test
```
