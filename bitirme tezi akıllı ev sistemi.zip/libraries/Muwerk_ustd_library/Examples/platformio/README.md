This project is used for CI testing.

In order to build it manually, copy all `*.h` files from the project's root into the `include` directory.
(Any external project would of course simply use the `ustd` library from either Arduino's or Platformio's
library repository.)

Then run:

`pio run`

