# Build

Make sure your build sets the required [platform define](https://github.com/muwerk/ustd/blob/master/README.md).
Alternatively, add the platform define (e.g. `#define __ATTINY__ 1`) before including `ustd` files. 
